
// Setup baseUrl ( server IP with 8000 django port )
export const baseUrl = 'http://192.168.1.13:8000/'

